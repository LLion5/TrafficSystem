import port
import time

for i in range(5):
    port.port_to_data(str(i),"3")
